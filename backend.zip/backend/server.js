const express = require("express");
const colors = require("colors");
const dotenv = require("dotenv").config();
const port = process.env.PORT || 5000;
const { errorHandler } = require("./middlewares/errorMiddleware");
const connectDB = require("./config/db.js");

connectDB();

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// API Routes
app.use("/api/users", require("./routes/userRoutes"));
app.use("/api/categories", require("./routes/categoryRoutes"));
app.use("/api/items", require("./routes/itemRoutes"));
app.use("/api/images", require("./routes/imageRoute"));

// Middlewares
app.use(errorHandler);

app.listen(port, () => console.log(`Backend server running at ${port}`));
