const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    const connection = await mongoose.connect(
      "mongodb+srv://arkar:arkar123@auctionhousecluster.qvwv7ne.mongodb.net/?retryWrites=true&w=majority&appName=AuctionHouseCluster"
    );

    console.log(
      `MongoDB connected: ${connection.connection.host}`.cyan.underline
    );
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
};

module.exports = connectDB;
