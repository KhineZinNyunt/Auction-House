const asyncHandler = require("express-async-handler");
const Category = require("../model/categoryModel");

// @desc Get Categories
// @route GET /api/categories
// @access Private
const getCategories = asyncHandler(async (req, res) => {
  const categories = await Category.find();

  res.status(200).json(categories);
});

// @desc Get One Category
// @route GET /api/categories/:id
// @access Private
const getOneCategory = asyncHandler(async (req, res) => {
  const category = await Category.findById(req.params.id);

  if (!Category) {
    res.status(404).json({ message: "Category does not exist" });
  }

  res.status(200).json(category);
});

// @desc Set Category
// @route POST /api/categories
// @access Private
const setCategory = asyncHandler(async (req, res) => {
  if (!req.body.name) {
    res.status(400);
    throw new Error("Please enter your category");
  }

  const category = await Category.create({
    name: req.body.name,
    description: req.body.description,
  });

  res.status(200).json(category);
});

// @desc Update Categorys
// @route PUT /api/Categorys/:id
// @access Private
const updateCategory = asyncHandler(async (req, res) => {
  const category = await Category.findById(req.params.id);

  if (!category) {
    res.status(400);
    throw new Error("Category not found");
  }

  const updatedCategory = await Category.findByIdAndUpdate(
    req.params.id,
    req.body,
    {
      new: true,
    }
  );

  res.status(200).json(updatedCategory);
});

// @desc DELETE Categorys
// @route DELETE /api/Categorys/:id
// @access Private
const deleteCategory = asyncHandler(async (req, res) => {
  const category = await Category.findById(req.params.id);

  if (!category) {
    res.status(400);
    throw new Error("Category not found");
  }

  await category.deleteOne();

  res.status(200).json({ message: `Delete Category: ${req.params.id}` });
});

module.exports = {
  getCategories,
  getOneCategory,
  setCategory,
  updateCategory,
  deleteCategory,
};
