const asyncHandler = require("express-async-handler");
const Image = require("../model/imageModel");

// @desc Set Image
// @route POST /api/images
// @access Private
const setImage = asyncHandler(async (req, res) => {
  try {
    if (!req.file) {
      return res.status(500).json({ error: "No file found" });
    }

    const imageFile = await Image.create({
      filename: req.file.filename,
      filepath: req.file.path,
    });

    res.status(200).json(imageFile);
  } catch (error) {
    console.log(error);
  }
});

module.exports = { setImage };
