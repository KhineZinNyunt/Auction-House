const express = require("express");
const { setImage } = require("../controllers/imageController");
const upload = require("../middlewares/imageUpload");
const { post } = require("./itemRoutes");

const router = express.Router();

router.route("/", upload.single("image")).post(setImage);

module.exports = router;
