const express = require("express");
const router = express.Router();

const {
  getCategories,
  getOneCategory,
  setCategory,
  updateCategory,
  deleteCategory,
} = require("../controllers/categoryController");

router.route("/").get(getCategories).post(setCategory);
router
  .route("/:id")
  .get(getOneCategory)
  .put(updateCategory)
  .delete(deleteCategory);

module.exports = router;
